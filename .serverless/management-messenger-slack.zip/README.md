# management-messenger-slack
Serverless framework, Lambda deploy 
